﻿namespace VehicleInventoryRileyOard
{
    partial class ViewVehicleInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.VehicleListBox = new System.Windows.Forms.ListBox();
            this.VehicleListLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.DateLabel = new System.Windows.Forms.Label();
            this.YearLabel = new System.Windows.Forms.Label();
            this.ModelLabel = new System.Windows.Forms.Label();
            this.MakeLabel = new System.Windows.Forms.Label();
            this.VINLabel = new System.Windows.Forms.Label();
            this.InvoiceLabel = new System.Windows.Forms.Label();
            this.MileageLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // VehicleListBox
            // 
            this.VehicleListBox.FormattingEnabled = true;
            this.VehicleListBox.Location = new System.Drawing.Point(49, 107);
            this.VehicleListBox.Name = "VehicleListBox";
            this.VehicleListBox.Size = new System.Drawing.Size(157, 173);
            this.VehicleListBox.TabIndex = 0;
            this.VehicleListBox.SelectedIndexChanged += new System.EventHandler(this.VehicleListBox_SelectedIndexChanged);
            // 
            // VehicleListLabel
            // 
            this.VehicleListLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.VehicleListLabel.Location = new System.Drawing.Point(49, 58);
            this.VehicleListLabel.Name = "VehicleListLabel";
            this.VehicleListLabel.Size = new System.Drawing.Size(209, 28);
            this.VehicleListLabel.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(346, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "VIN#:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(346, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Make:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(346, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Model:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(346, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Year:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(346, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Invoice Price:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(346, 246);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Mileage:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(346, 280);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Purchase Date:";
            // 
            // DateLabel
            // 
            this.DateLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DateLabel.Location = new System.Drawing.Point(433, 279);
            this.DateLabel.Name = "DateLabel";
            this.DateLabel.Size = new System.Drawing.Size(100, 23);
            this.DateLabel.TabIndex = 10;
            // 
            // YearLabel
            // 
            this.YearLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.YearLabel.Location = new System.Drawing.Point(433, 175);
            this.YearLabel.Name = "YearLabel";
            this.YearLabel.Size = new System.Drawing.Size(100, 23);
            this.YearLabel.TabIndex = 11;
            // 
            // ModelLabel
            // 
            this.ModelLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ModelLabel.Location = new System.Drawing.Point(433, 135);
            this.ModelLabel.Name = "ModelLabel";
            this.ModelLabel.Size = new System.Drawing.Size(100, 23);
            this.ModelLabel.TabIndex = 12;
            // 
            // MakeLabel
            // 
            this.MakeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MakeLabel.Location = new System.Drawing.Point(433, 96);
            this.MakeLabel.Name = "MakeLabel";
            this.MakeLabel.Size = new System.Drawing.Size(100, 23);
            this.MakeLabel.TabIndex = 13;
            // 
            // VINLabel
            // 
            this.VINLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.VINLabel.Location = new System.Drawing.Point(433, 58);
            this.VINLabel.Name = "VINLabel";
            this.VINLabel.Size = new System.Drawing.Size(100, 23);
            this.VINLabel.TabIndex = 14;
            // 
            // InvoiceLabel
            // 
            this.InvoiceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.InvoiceLabel.Location = new System.Drawing.Point(433, 211);
            this.InvoiceLabel.Name = "InvoiceLabel";
            this.InvoiceLabel.Size = new System.Drawing.Size(100, 23);
            this.InvoiceLabel.TabIndex = 15;
            // 
            // MileageLabel
            // 
            this.MileageLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MileageLabel.Location = new System.Drawing.Point(433, 245);
            this.MileageLabel.Name = "MileageLabel";
            this.MileageLabel.Size = new System.Drawing.Size(100, 23);
            this.MileageLabel.TabIndex = 16;
            // 
            // ViewVehicleInfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 356);
            this.Controls.Add(this.MileageLabel);
            this.Controls.Add(this.InvoiceLabel);
            this.Controls.Add(this.VINLabel);
            this.Controls.Add(this.MakeLabel);
            this.Controls.Add(this.ModelLabel);
            this.Controls.Add(this.YearLabel);
            this.Controls.Add(this.DateLabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.VehicleListLabel);
            this.Controls.Add(this.VehicleListBox);
            this.Name = "ViewVehicleInfoForm";
            this.Text = "ViewVehicleInfoForm";
            this.Load += new System.EventHandler(this.ViewVehicleInfoForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox VehicleListBox;
        private System.Windows.Forms.Label VehicleListLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label DateLabel;
        private System.Windows.Forms.Label YearLabel;
        private System.Windows.Forms.Label ModelLabel;
        private System.Windows.Forms.Label MakeLabel;
        private System.Windows.Forms.Label VINLabel;
        private System.Windows.Forms.Label InvoiceLabel;
        private System.Windows.Forms.Label MileageLabel;
    }
}