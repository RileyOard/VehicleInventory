﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VehicleInventoryRileyOard
{
    public partial class ViewVehicleInfoForm : Form
    {
        public ViewVehicleInfoForm()
        {
            InitializeComponent();
        }

        private void ViewVehicleInfoForm_Load(object sender, EventArgs e)
        {
            if (CreateVehicle.VehicleTypeSelection == 1) //Car
            {
                foreach (Car Vehicle in CreateVehicle.CarList)
                {
                    VehicleListBox.Items.Add(Vehicle.VIN);
                }
                VehicleListLabel.Text = "Here are our Cars.";
            }
            else if (CreateVehicle.VehicleTypeSelection == 2) //Truck
            {
                foreach (Truck Vehicle in CreateVehicle.TruckList)
                {
                    VehicleListBox.Items.Add(Vehicle.VIN);
                }
                VehicleListLabel.Text = "Here are our Trucks.";
            }
        }

        private void VehicleListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (VehicleListBox.SelectedIndex != -1)
            {
                int row = VehicleListBox.SelectedIndex;
                if (CreateVehicle.VehicleTypeSelection == 1) //car
                {
                    VINLabel.Text = CreateVehicle.CarList[row].VIN;
                    MakeLabel.Text = CreateVehicle.CarList[row].Make;
                    ModelLabel.Text = CreateVehicle.CarList[row].Model;
                    YearLabel.Text = CreateVehicle.CarList[row].Year.ToString();
                    InvoiceLabel.Text = CreateVehicle.CarList[row].Invoice.ToString("C");
                    MileageLabel.Text = CreateVehicle.CarList[row].Mileage.ToString();
                    DateLabel.Text = CreateVehicle.CarList[row].Date;
                }
                else
                {
                    VINLabel.Text = CreateVehicle.TruckList[row].VIN;
                    MakeLabel.Text = CreateVehicle.TruckList[row].Make;
                    ModelLabel.Text = CreateVehicle.TruckList[row].Model;
                    YearLabel.Text = CreateVehicle.TruckList[row].Year.ToString();
                    InvoiceLabel.Text = CreateVehicle.TruckList[row].Invoice.ToString("C");
                    MileageLabel.Text = CreateVehicle.TruckList[row].Mileage.ToString();
                    DateLabel.Text = CreateVehicle.TruckList[row].Date;
                }
            }
            else
                MessageBox.Show("Please sleect a Vehicle to view.");
        }
    }
}
