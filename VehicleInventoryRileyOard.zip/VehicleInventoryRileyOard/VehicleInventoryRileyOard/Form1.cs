﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace VehicleInventoryRileyOard
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CreateButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (VINTextBox.Text.Trim() != "" && MakeTextBox.Text.Trim() != "" && ModelTextBox.Text.Trim() != "")
                {
                    int year = int.Parse(YearTextBox.Text);
                    decimal invoice = decimal.Parse(InvoiceTextBox.Text);
                    int mileage = int.Parse(MileageTextBox.Text);
                    if (year > 1900 && year < 2020 && invoice > 0 && invoice < 100000 && mileage >= 0 && DateTextBox.Text.Trim() != "")
                    {
                        if (CarRadioButton.Checked)
                        {
                            Car Vehicle = new Car();
                            Vehicle.VIN = VINTextBox.Text;
                            Vehicle.Make = MakeTextBox.Text;
                            Vehicle.Model = ModelTextBox.Text;
                            Vehicle.Year = year;
                            Vehicle.Invoice = invoice;
                            Vehicle.Mileage = mileage;
                            Vehicle.Date = DateTextBox.Text;
                            CreateVehicle.CarList.Add(Vehicle);
                            MessageBox.Show("Vehicle Added.");
                            ClearButton_Click(sender, e);
                        }
                        else if (TruckRadioButton.Checked)
                        {
                            Truck Vehicle = new Truck();
                            Vehicle.VIN = VINTextBox.Text;
                            Vehicle.Make = MakeTextBox.Text;
                            Vehicle.Model = ModelTextBox.Text;
                            Vehicle.Year = year;
                            Vehicle.Invoice = invoice;
                            Vehicle.Mileage = mileage;
                            Vehicle.Date = DateTextBox.Text;
                            CreateVehicle.TruckList.Add(Vehicle);
                            MessageBox.Show("Vehicle Added.");
                            ClearButton_Click(sender, e);
                        }
                        else
                        {
                            MessageBox.Show("Please Select Truck or Car.");
                        }
                    }
                    else
                        MessageBox.Show("Please Enter Year, Invoice Price, Mileage, and Date");
                }
                else
                    MessageBox.Show("Please Enter VIN#, Make, and Model");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            VINTextBox.Text = "";
            MakeTextBox.Text = "";
            ModelTextBox.Text = "";
            YearTextBox.Text = "";
            InvoiceTextBox.Text = "";
            MileageTextBox.Text = "";
            DateTextBox.Text = "";
            TruckRadioButton.Checked = false;
            CarRadioButton.Checked = false;
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ViewAllButton_Click(object sender, EventArgs e)
        {
            if (CarRadioButton.Checked)
                CreateVehicle.VehicleTypeSelection = 1;
            else if (TruckRadioButton.Checked)
                CreateVehicle.VehicleTypeSelection = 2;
            else
                CreateVehicle.VehicleTypeSelection = 0;

            if (CreateVehicle.VehicleTypeSelection != 0) // make sure a radio button was selected
            {
                //create a form object and display
                ViewVehicleInfoForm aVehicleForm = new ViewVehicleInfoForm();
                aVehicleForm.ShowDialog();
            }
            else
                MessageBox.Show("Please select an Vehicle type to view.");

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult answer;
            answer = MessageBox.Show("Save data?", "Save", MessageBoxButtons.YesNoCancel);
            if (answer == System.Windows.Forms.DialogResult.Yes)
            {

                //save all objects in our two lists to  files:
                StreamWriter CarWriter = new StreamWriter("Cars.txt");
                foreach (Car aCar in CreateVehicle.CarList)
                {
                    CarWriter.Write(aCar.VIN + ",");
                    CarWriter.Write(aCar.Make + ",");
                    CarWriter.Write(aCar.Model + ",");
                    CarWriter.Write(aCar.Year + ",");
                    CarWriter.Write(aCar.Invoice + ",");
                    CarWriter.Write(aCar.Mileage + ",");
                    CarWriter.WriteLine(aCar.Date);
                }

                CarWriter.Close();

                StreamWriter TruckWriter = new StreamWriter("Trucks.txt");
                foreach (Truck aTruck in CreateVehicle.TruckList)
                {
                    TruckWriter.Write(aTruck.VIN + ",");
                    TruckWriter.Write(aTruck.Make + ",");
                    TruckWriter.Write(aTruck.Model + ",");
                    TruckWriter.Write(aTruck.Year + ",");
                    TruckWriter.Write(aTruck.Invoice + ",");
                    TruckWriter.Write(aTruck.Mileage + ",");
                    TruckWriter.WriteLine(aTruck.Date);
                }
                TruckWriter.Close();

            }
            else if (answer == System.Windows.Forms.DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                CreateVehicle.CarList = new List<Car>();
                CreateVehicle.TruckList = new List<Truck>();

                StreamReader CarReader = new StreamReader("Cars.txt");
                StreamReader TruckReader = new StreamReader("Trucks.txt");

                string eachVehicle = "";
                string[] splitVehicle = new string[7];

                while (!CarReader.EndOfStream)
                {
                    Car CarVehicle = new Car();
                    eachVehicle = CarReader.ReadLine();
                    splitVehicle = eachVehicle.Split(',');
                    CarVehicle.VIN = splitVehicle[0];
                    CarVehicle.Make = splitVehicle[1];
                    CarVehicle.Model = splitVehicle[2];
                    CarVehicle.Year = int.Parse(splitVehicle[3]);
                    CarVehicle.Invoice = decimal.Parse(splitVehicle[4]);
                    CarVehicle.Mileage = int.Parse(splitVehicle[5]);
                    CarVehicle.Date = splitVehicle[6];
                    Car.CarList.Add(CarVehicle);
                }

                CarReader.Close();

                while (!TruckReader.EndOfStream)
                {
                    Truck TruckVehicle = new Truck();
                    eachVehicle = TruckReader.ReadLine();
                    splitVehicle = eachVehicle.Split(',');

                    TruckVehicle.VIN = splitVehicle[0];
                    TruckVehicle.Make = splitVehicle[1];
                    TruckVehicle.Model = splitVehicle[2];
                    TruckVehicle.Year = int.Parse(splitVehicle[3]);
                    TruckVehicle.Invoice = decimal.Parse(splitVehicle[4]);
                    TruckVehicle.Mileage = int.Parse(splitVehicle[5]);
                    TruckVehicle.Date = splitVehicle[6];
                    Truck.TruckList.Add(TruckVehicle);
                }
                TruckReader.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
