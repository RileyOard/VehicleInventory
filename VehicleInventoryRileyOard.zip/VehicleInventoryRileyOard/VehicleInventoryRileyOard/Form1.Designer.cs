﻿namespace VehicleInventoryRileyOard
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.VINTextBox = new System.Windows.Forms.TextBox();
            this.MakeTextBox = new System.Windows.Forms.TextBox();
            this.ModelTextBox = new System.Windows.Forms.TextBox();
            this.YearTextBox = new System.Windows.Forms.TextBox();
            this.InvoiceTextBox = new System.Windows.Forms.TextBox();
            this.MileageTextBox = new System.Windows.Forms.TextBox();
            this.DateTextBox = new System.Windows.Forms.TextBox();
            this.TruckRadioButton = new System.Windows.Forms.RadioButton();
            this.CarRadioButton = new System.Windows.Forms.RadioButton();
            this.CreateButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.ViewAllButton = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "VIN#:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Make:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Model:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Year:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Invoice Price:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Mileage:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(30, 274);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Date Purchased:";
            // 
            // VINTextBox
            // 
            this.VINTextBox.Location = new System.Drawing.Point(123, 35);
            this.VINTextBox.Name = "VINTextBox";
            this.VINTextBox.Size = new System.Drawing.Size(100, 20);
            this.VINTextBox.TabIndex = 7;
            // 
            // MakeTextBox
            // 
            this.MakeTextBox.Location = new System.Drawing.Point(123, 72);
            this.MakeTextBox.Name = "MakeTextBox";
            this.MakeTextBox.Size = new System.Drawing.Size(100, 20);
            this.MakeTextBox.TabIndex = 8;
            // 
            // ModelTextBox
            // 
            this.ModelTextBox.Location = new System.Drawing.Point(123, 111);
            this.ModelTextBox.Name = "ModelTextBox";
            this.ModelTextBox.Size = new System.Drawing.Size(100, 20);
            this.ModelTextBox.TabIndex = 9;
            // 
            // YearTextBox
            // 
            this.YearTextBox.Location = new System.Drawing.Point(123, 150);
            this.YearTextBox.Name = "YearTextBox";
            this.YearTextBox.Size = new System.Drawing.Size(100, 20);
            this.YearTextBox.TabIndex = 10;
            // 
            // InvoiceTextBox
            // 
            this.InvoiceTextBox.Location = new System.Drawing.Point(123, 189);
            this.InvoiceTextBox.Name = "InvoiceTextBox";
            this.InvoiceTextBox.Size = new System.Drawing.Size(100, 20);
            this.InvoiceTextBox.TabIndex = 11;
            // 
            // MileageTextBox
            // 
            this.MileageTextBox.Location = new System.Drawing.Point(123, 231);
            this.MileageTextBox.Name = "MileageTextBox";
            this.MileageTextBox.Size = new System.Drawing.Size(100, 20);
            this.MileageTextBox.TabIndex = 12;
            // 
            // DateTextBox
            // 
            this.DateTextBox.Location = new System.Drawing.Point(123, 271);
            this.DateTextBox.Name = "DateTextBox";
            this.DateTextBox.Size = new System.Drawing.Size(100, 20);
            this.DateTextBox.TabIndex = 13;
            // 
            // TruckRadioButton
            // 
            this.TruckRadioButton.AutoSize = true;
            this.TruckRadioButton.Location = new System.Drawing.Point(270, 272);
            this.TruckRadioButton.Name = "TruckRadioButton";
            this.TruckRadioButton.Size = new System.Drawing.Size(53, 17);
            this.TruckRadioButton.TabIndex = 14;
            this.TruckRadioButton.TabStop = true;
            this.TruckRadioButton.Text = "Truck";
            this.TruckRadioButton.UseVisualStyleBackColor = true;
            // 
            // CarRadioButton
            // 
            this.CarRadioButton.AutoSize = true;
            this.CarRadioButton.Location = new System.Drawing.Point(270, 249);
            this.CarRadioButton.Name = "CarRadioButton";
            this.CarRadioButton.Size = new System.Drawing.Size(41, 17);
            this.CarRadioButton.TabIndex = 15;
            this.CarRadioButton.TabStop = true;
            this.CarRadioButton.Text = "Car";
            this.CarRadioButton.UseVisualStyleBackColor = true;
            // 
            // CreateButton
            // 
            this.CreateButton.Location = new System.Drawing.Point(123, 297);
            this.CreateButton.Name = "CreateButton";
            this.CreateButton.Size = new System.Drawing.Size(100, 23);
            this.CreateButton.TabIndex = 16;
            this.CreateButton.Text = "Add Vehicle";
            this.CreateButton.UseVisualStyleBackColor = true;
            this.CreateButton.Click += new System.EventHandler(this.CreateButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(140, 326);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(68, 23);
            this.ClearButton.TabIndex = 17;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(140, 355);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(68, 23);
            this.ExitButton.TabIndex = 18;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // ViewAllButton
            // 
            this.ViewAllButton.Location = new System.Drawing.Point(96, 399);
            this.ViewAllButton.Name = "ViewAllButton";
            this.ViewAllButton.Size = new System.Drawing.Size(155, 23);
            this.ViewAllButton.TabIndex = 19;
            this.ViewAllButton.Text = "View all Vehicles in selection";
            this.ViewAllButton.UseVisualStyleBackColor = true;
            this.ViewAllButton.Click += new System.EventHandler(this.ViewAllButton_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 287);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "(MM/DD/YYYY)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 445);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ViewAllButton);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.CreateButton);
            this.Controls.Add(this.CarRadioButton);
            this.Controls.Add(this.TruckRadioButton);
            this.Controls.Add(this.DateTextBox);
            this.Controls.Add(this.MileageTextBox);
            this.Controls.Add(this.InvoiceTextBox);
            this.Controls.Add(this.YearTextBox);
            this.Controls.Add(this.ModelTextBox);
            this.Controls.Add(this.MakeTextBox);
            this.Controls.Add(this.VINTextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Add Vehicle Inventory";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox VINTextBox;
        private System.Windows.Forms.TextBox MakeTextBox;
        private System.Windows.Forms.TextBox ModelTextBox;
        private System.Windows.Forms.TextBox YearTextBox;
        private System.Windows.Forms.TextBox InvoiceTextBox;
        private System.Windows.Forms.TextBox MileageTextBox;
        private System.Windows.Forms.TextBox DateTextBox;
        private System.Windows.Forms.RadioButton TruckRadioButton;
        private System.Windows.Forms.RadioButton CarRadioButton;
        private System.Windows.Forms.Button CreateButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button ViewAllButton;
        private System.Windows.Forms.Label label8;
    }
}

