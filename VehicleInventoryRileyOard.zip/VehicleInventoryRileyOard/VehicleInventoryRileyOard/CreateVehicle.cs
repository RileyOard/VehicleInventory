﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleInventoryRileyOard
{
    class CreateVehicle
    {
        public static List<Car> CarList;
        public static List<Truck> TruckList;

        public static int VehicleTypeSelection;

        string VehicleVIN;
        string VehicleMake;
        string VehicleModel;
        int VehicleYear;
        decimal VehicleInvoice;
        int VehicleMileage;
        string VehicleDate;

        public CreateVehicle()
        {
            VehicleVIN = "";
            VehicleMake = "";
            VehicleModel = "";
            VehicleYear = 0;
            VehicleInvoice = 0;
            VehicleMileage = 0;
            VehicleDate = "";
        }

        public string VIN
        {
            get { return VehicleVIN; }
            set { VehicleVIN = value; }
        }
        
        public string Make
        {
            get { return VehicleMake; }
            set { VehicleMake = value; }
        }

        public string Model
        {
            get { return VehicleModel; }
            set { VehicleModel = value; }
        }

        public int Year
        {
            get { return VehicleYear; }
            set { VehicleYear = value; }
        }

        public decimal Invoice 
        {
            get { return VehicleInvoice; }
            set { VehicleInvoice = value; }
        }

        public int Mileage
        {
            get { return VehicleMileage; }
            set { VehicleMileage = value; }
        }

        public string Date
        {
            get { return VehicleDate; }
            set { VehicleDate = value; }
        }

    }
}
